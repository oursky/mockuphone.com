from .image import mockup as startMockup  # noqa: F401
