from .image_mockup import mockup as startMockup  # noqa: F401
